/* ═══════════════════════════════════════════════
   Carbon Atlantic — Interactions & Contact JS
   ═══════════════════════════════════════════════ */

// ── NAV SCROLL STATE ──
const nav = document.getElementById('nav');
window.addEventListener('scroll', () =>
  nav.classList.toggle('scrolled', window.scrollY > 50)
);

// ── PRODUCT IMAGE LIGHTBOX ──
(function initLightbox() {
  const overlay = document.getElementById('lightboxOverlay');
  const lbImg   = document.getElementById('lightboxImg');
  const lbCap   = document.getElementById('lightboxCaption');
  const closeBtn = document.getElementById('lightboxClose');

  function openLightbox(src, alt) {
    lbImg.src = src;
    lbImg.alt = alt || '';
    lbCap.textContent = alt || '';
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    overlay.classList.remove('active');
    document.body.style.overflow = '';
    // slight delay to let fade out finish before clearing src
    setTimeout(() => { lbImg.src = ''; }, 300);
  }

  // Zoom buttons
  document.querySelectorAll('.img-zoom-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const img = btn.closest('.product-img').querySelector('img');
      openLightbox(img.src, img.alt);
    });
  });

  // Also allow clicking the image itself
  document.querySelectorAll('.product-img img').forEach(img => {
    img.addEventListener('click', () => openLightbox(img.src, img.alt));
  });

  // Close via X button
  closeBtn.addEventListener('click', closeLightbox);

  // Close on overlay backdrop click
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeLightbox();
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay.classList.contains('active')) closeLightbox();
  });
})();

// ── CONTACT FORM — REQUEST A QUOTE ──
(function initContactForm() {
  const submitBtn = document.querySelector('.form-submit');
  if (!submitBtn) return;

  submitBtn.addEventListener('click', function () {
    const inputs = document.querySelectorAll(
      '.contact-form input, .contact-form select, .contact-form textarea'
    );

    let allFilled = true;
    inputs.forEach(input => {
      const empty = !input.value.trim();
      input.style.borderColor = empty ? 'rgba(201,80,80,0.6)' : '';
      if (empty) allFilled = false;
    });

    if (!allFilled) {
      this.textContent = 'Please fill all fields';
      this.style.background = '#8a4030';
      setTimeout(() => {
        this.textContent = 'Send Inquiry';
        this.style.background = '';
      }, 2500);
      return;
    }

    // Gather form data for optional future integration
    const formData = {
      firstName: document.querySelector('.contact-form input[placeholder="Name"]')?.value || '',
      lastName:  document.querySelector('.contact-form input[placeholder="Last Name"]')?.value || '',
      company:   document.querySelector('.contact-form input[placeholder="Your company name"]')?.value || '',
      country:   document.querySelector('.contact-form input[placeholder*="Germany"]')?.value || '',
      product:   document.querySelectorAll('.contact-form select')[0]?.value || '',
      volume:    document.querySelectorAll('.contact-form select')[1]?.value || '',
      message:   document.querySelector('.contact-form textarea')?.value || '',
    };
    console.log('[Carbon Atlantic] Quote request:', formData);

    this.textContent = 'Message Sent ✓';
    this.style.background = '#3a6a3a';

    setTimeout(() => {
      this.textContent = 'Send Inquiry';
      this.style.background = '';
      inputs.forEach(i => (i.value = ''));
    }, 3000);
  });
})();
